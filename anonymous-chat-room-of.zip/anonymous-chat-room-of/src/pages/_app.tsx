
import type { AppProps } from 'next/app';
import '@livekit/components-styles';
// import '@/styles/components-styles';
import '@livekit/components-styles/prefabs';
// import '@/styles/general/index.css'
import '../styles/globals.css';
import { DefaultSeo } from 'next-seo';
import TopBar from '@/components/TopBar';
import Script from 'next/script';
import '../i18n/config'; // 引用配置文件
function MyApp({ Component, pageProps }: AppProps) {
    return (
        <>
            <DefaultSeo
                title="Anonymous Chat Room Power By Livekit And Next.js"
                titleTemplate="%s"
                defaultTitle="Anonymous Chat Room Power By Livekit And Next.js"
                description="Anonymous Chat Room Power By Livekit And Next.js"
                twitter={{
                    handle: '@livekitted',
                    site: '@livekitted',
                    cardType: 'summary_large_image',
                }}
                openGraph={{
                    url: 'https://chat.cwy666.com',
                    images: [
                        {
                            url: 'https://meet.livekit.io/images/livekit-meet-open-graph.png',
                            width: 2000,
                            height: 1000,
                            type: 'image/png',
                        },
                    ],
                    site_name: 'Anonymous Chat Room',
                }}
                additionalMetaTags={[
                    {
                        property: 'theme-color',
                        content: '#070707',
                    },
                ]}
                additionalLinkTags={[
                    {
                        rel: 'icon',
                        href: '/favicon.ico',
                    },
                    {
                        rel: 'apple-touch-icon',
                        href: '/images/livekit-apple-touch.png',
                        sizes: '180x180',
                    },
                    {
                        rel: 'mask-icon',
                        href: '/images/livekit-safari-pinned-tab.svg',
                        color: '#070707',
                    },
                ]}
            />
            <TopBar />
            <Component {...pageProps} />
            <script type="text/javascript" src={process.env.NEXT_PUBLIC_WSPLAYER_JS_URL || 'https://quantil.jsdelivr.net/gh/tokamakz/wsPlayer/wsPlayer.js'}></script>
            <script type="text/javascript" src={process.env.NEXT_PUBLIC_M4BOX_JS_URL || 'https://quantil.jsdelivr.net/gh/tokamakz/wsPlayer/mp4box.all.min.js'}></script>
            {/* <Script src="https://www.WebRTC-Experiment.com/RecordRTC.js"></Script> */}
            {process.env.NEXT_PUBLIC_UMAMI_URL != undefined && process.env.NEXT_PUBLIC_UMAMI_URL != "" && (
                <Script
                    src={process.env.NEXT_PUBLIC_UMAMI_URL}
                    strategy='afterInteractive'
                    data-website-id={process.env.NEXT_PUBLIC_UMAMI_ID}
                />
            )}
            {
                process.env.NEXT_PUBLIC_USE_TENCENT_LEB === 'true' && (
                    <Script type="text/javascript" src="https://video.sdk.qcloudecdn.com/web/TXLivePlayer-1.3.2.min.js"></Script>
                )
            }
            {
                process.env.NEXT_PUBLIC_USE_ALI_RTS === 'true' && (
                    <Script type="text/javascript" src="https://g.alicdn.com/apsara-media-box/imp-web-rts-sdk/2.5.1/aliyun-rts-sdk.js"></Script>
                )
            }
            {
                process.env.NEXT_PUBLIC_USE_SHAREVIDEO === 'true' && (
                    <Script type="text/javascript" src='./ZLMRTCClient.js'></Script>
                )
            }
            {
                process.env.NEXT_PUBLIC_USE_TENCENT_LEB === 'true' && (
                    <Script type="text/javascript" src="https://web.sdk.qcloud.com/player/tcplayer/release/v4.9.1/tcplayer.v4.9.1.min.js"></Script>
                )
            }
            {
                process.env.NEXT_PUBLIC_USE_SHAREVIDEO === 'true' && (
                    <Script type="text/javascript" src={process.env.NEXT_PUBLIC_FLV_JS_URL || 'https://cdn.staticfile.org/flv.js/1.6.2/flv.min.js'}></Script>
                )
            }
            {
                process.env.NEXT_PUBLIC_USE_SHAREVIDEO === 'true' && (
                    <Script type="text/javascript" src={process.env.NEXT_PUBLIC_HLS_JS_URL || 'https://cdnjs.cloudflare.com/ajax/libs/hls.js/1.6.13/hls.min.js'}></Script>
                )
            }
        </>
    );
}

export default MyApp;
